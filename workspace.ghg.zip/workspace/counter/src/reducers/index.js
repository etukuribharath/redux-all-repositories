export default (state = 0, action) => {
  switch (action.type) {
    case 'INCREMENT':
      return state + 1
    case 'DECREMENT':
      return state - 1
    case 'TEST':
      return state - 10
    case 'SOMETHING':
    	return state+10
    default:
      return state
  }
}