// var testArray = ['d','a','b','c','e']

// function sortedArray(){

// 	Array.prototype.remove = function(index) {
//     this.splice(index, 1);
// 		}

// 	for(var i=arguments.length-1;i>=0;i--){
// 		testArray.remove(testArray.indexOf(arguments[i]));
// 		testArray.unshift(arguments[i]);
// 	}
// }

// sortedArray.apply(undefined,['b','c','d']);

// console.log(testArray)


var testArray = ['d','a','b','c','e','g']

//function to remove an element from array
Array.prototype.remove = function(index) {
    this.splice(index, 1);
		}

// function to sort an array
function sortedArray(){

		for(var i=arguments.length-1;i>=0;i--){
		this.remove(this.indexOf(arguments[i]));
		this.unshift(arguments[i]);
	}
}

//pass the arguments in the form of array
sortedArray.apply(testArray,['b','c','d']);

//pass the arguments list
sortedArray.call(testArray,'b','e')

console.log(testArray)