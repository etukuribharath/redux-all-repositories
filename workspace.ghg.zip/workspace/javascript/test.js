Array.prototype.push = function(element) {
   console.log(array);
}
var array = [];
array.push(1);
array.push.apply(array,[2,3]);


var z = ['a','b','c','d']

function b(){
	// console.log(arguments[0])
	for(var i=arguments.length-1;i>=0;i--){
		// console.log(z.indexOf('b'));
		console.log(z.indexOf(arguments[i]));
		z.splice(z.indexOf(arguments[i]));
	z.unshift(arguments[i]);
	}
	
	console.log(z);
	// var c = z.indexOf(e);
	// var d = z.indexOf(f);
	// z.splice(c,d);
	// z.unshift(f);
	// z.unshift(e);
	// console.log(z)

}

b.apply(undefined,['b','c'])


// b.apply(1,2)

// Array.prototype.push = function(element) {
//    /*
//    Native code*, that uses 'this'       
//    this.put(element);
//    */
// }
// var array = [];
// array.push.apply(array,['a','b']);
// console.log(array);
// // var f=['a','b'];
// // b.apply(undefined,f);

