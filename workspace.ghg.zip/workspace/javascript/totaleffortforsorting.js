// var testArray=['b','c','e','f','d'];

// function sortedArray(){
// console.log(this);
// 	for(var i=0;i<arguments.length;i++){
// 		console.log(i);
// 		console.log(arguments[i]);
// 		console.log(testArray.indexOf(0))
// 		console.log(testArray.indexOf(arguments[i]));
// 		this.splice(this.indexOf(arguments[i]));
// 	  this.unshift(arguments[arguments.length-1]);
// 	}
// 	console.log(this);
// }

// sortedArray.apply(testArray,['b','c','d'])


var testArray = ['d','a','b','c','e']
	Array.prototype.remove = function(index) {
    this.splice(index, 1);
		}
	// console.log(arguments[0])
	// testArray.splice(arguments);
	for(var i=arguments.length-1;i>=0;i--){
		// console.log(testArray.indexOf('b'));
		testArray.remove(testArray.indexOf(arguments[i]));
		console.log(arguments[i]);
	testArray.unshift(arguments[i]);
	}
	
	console.log(testArray);
	// var c = testArray.indexOf(e);
	// var d = testArray.indexOf(f);
	// testArray.splice(c,d);
	// testArray.unshift(f);
	// testArray.unshift(e);
	// console.log(testArray)

}

sortedArray.apply(undefined,['b','c','d']);
console.log(testArray)