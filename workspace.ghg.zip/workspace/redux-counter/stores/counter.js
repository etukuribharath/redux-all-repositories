import {INCREMENT_COUNTER, DECREMENT_COUNTER} from '../constants/actiontypes';

export default function counter(state=0, action){
	console.log(action.type==DECREMENT_COUNTER);
	switch(action.type){
		case INCREMENT_COUNTER:
		console.log(state+1)
		return state+1
		case DECREMENT_COUNTER:
		console.log(state-1)
		return state-1
		default:
		return state
	}
}