import React from 'react';
import CounterApp from './containers/CounterApp';

React.render(
  <CounterApp />,
  document.getElementById('root')
);