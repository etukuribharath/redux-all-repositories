import React from 'react';
import CounterApp from './CounterApp';
import {createStore} from 'redux';
import {Provider} from 'redux';
import  stores from '../stores/counter';

const redux = createStore(stores);

export default class App{
	render(){
		return(
			<Provider redux={redux}>
			{()=><CounterApp/>}
			</Provider>
			);
	}
}