import React from 'react';
import { bindActionCreators } from 'redux';
import { createStore } from 'redux';
import Counter from '../components/Counter';
import {increment, decrement} from '../actions/index';
import reducer from '../stores/counter'

export const store = createStore(reducer);




export default class CounterApp {
	
	handleChange(){
		var value = store.getState()
		console.log(value);
		store.subscribe(()=>value=store.getState())
		return value
				}
  render() {
    return (
      <Counter value={this.handleChange.bind()}
      			onIncrement={()=>store.dispatch(increment())}
      			onDecrement={()=>store.dispatch(decrement())}/>            
    
    );
  }
}

