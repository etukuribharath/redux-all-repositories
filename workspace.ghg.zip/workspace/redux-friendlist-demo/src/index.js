import React from 'react';
import App from './containers/App';

React.render(<App />, document.getElementById('root'));
